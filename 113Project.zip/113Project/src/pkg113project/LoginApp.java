
package pkg113project;

//imported libraries
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class LoginApp extends Application {
    //String used to connect to the main database
    static final String DB = "jdbc:sqlite:Registration.db";
    
    public void start(Stage primaryStage){
        //Formatting the application with controls
        Label lblUser = new Label("Username:");
        TextField txtUser = new TextField();
        
        Label lblPass = new Label("Password:");
        PasswordField txtPass = new PasswordField();
        
        Image image = new Image("File:SchoolDistrictLogin.png");
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(185);
        imageView.setFitWidth(400);
        
        Button btnLogin = new Button("Login");
        Button btnExit = new Button("Exit");
        
        //Using gridpane to arrange buttons, labels, textfields, etc.
        GridPane layout = new GridPane();
        layout.setHgap(20);
        layout.setVgap(10);
        
        //GridPane and image inserted into BorderPane for better formatting
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(imageView);
        borderPane.setCenter(layout);
        
        //Adding controls to layout
        layout.add(lblUser,0,1);
        layout.add(txtUser,0,2);
        layout.add(lblPass,1,1);
        layout.add(txtPass,1,2);
        layout.add(btnLogin,0,7);
        layout.add(btnExit,1,7);
        
        //Action Event for the login button
        btnLogin.setOnAction(e ->{
            //Grabbing inserted Strings from txtUser and txtPass and
            //matching them with their own variables
            String username = txtUser.getText();
            String password = txtPass.getText();
            
            //try-catch statement to connect to database
            try{
            //connecting to database
            Connection conn = DriverManager.getConnection(DB);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT username, password FROM Login");
            boolean valid = false;
            
            //program iterates through every value in the registration table
            //from the registration database. If the username and password
            //inserted into the application respectively matches a username
            //and password in the database, then the login is accepted
            while(rs.next()){
                if(rs.getString("username").equals(username) &&
                        rs.getString("password").equals(password)){
                    valid = true;
                    break;
                }
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            if(valid){
                JOptionPane.showMessageDialog(null, "Login Successful!");
                primaryStage.hide();
                GUIChoice g = new GUIChoice();
                g.start(new Stage());
            } // If program fails to locate a match, print error message
            else if(!valid){
                JOptionPane.showMessageDialog(null, "Login failed. Please try again.");
                
                txtUser.setText(null);
                txtPass.setText(null);
            }
            }
            catch(Exception ex){
                System.out.println(ex.toString());
            }
        });
        
        //Action Event for exit button, closes application and ends program
        btnExit.setOnAction(e->{
            Platform.exit();
        });
        
        //Create the scene and display it on the stage
        Scene scene = new Scene(borderPane,400,350);
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Login");
    }
    
    //Main function
    public static void main(String[] args) {
        launch(args);
    }
    
}
