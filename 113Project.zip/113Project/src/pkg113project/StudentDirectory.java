
package pkg113project;

//imported libraries
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Optional;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class StudentDirectory extends Application {

    //String variable used to connect to the database
    static final String DB = "jdbc:sqlite:Registration.db";
    
    //Function that displays the stage
    @Override
    public void start(Stage primaryStage){
        //Formatting and controls for the application
        Font titleFont = Font.font("Bell MT",FontWeight.BOLD,40);
        
        Label lblEmpty = new Label("");
        Label lblEmpty2 = new Label("");
        BackgroundFill backgroundColor = new BackgroundFill(Color.DARKRED, CornerRadii.EMPTY, Insets.EMPTY);
        Background background = new Background(backgroundColor);
        
        Label lblDir = new Label("Student Directory");
        lblDir.setFont(titleFont);
        lblDir.setTextFill(Color.color(1,1,1));
        lblDir.setUnderline(true);
        Label lblStudentName = new Label("Name:");
        Label lblStudentBirth = new Label("Student DOB:");
        Label lblAddress = new Label("Address:");
        Label lblCity = new Label("City:");
        Label lblState = new Label("State:");
        Label lblZip = new Label("Zip Code:");
        
        Label lblParent1 = new Label("Parent 1:");
        Label lblParentName1 = new Label("Name:");
        Label lblParentBirth1 = new Label("DOB:");
        Label lblParentPhone1 = new Label("Phone Number:");
        Label lblParent2 = new Label("Parent 2:");
        Label lblParentName2 = new Label("Name:");
        Label lblParentBirth2 = new Label("DOB:");
        Label lblParentPhone2 = new Label("Phone Number:");
        
        //Students IDs are displays via a listview
        ListView<String> listView = new ListView<>();
        
        Button btnDel = new Button("Delete");
        Button btnBack = new Button("<- Back");
        Button btnInfo = new Button("More Info");
        
        //Multiple gridpanes for different parts of the application in
        //order to improve formatting
        GridPane studentInfo = new GridPane();
        studentInfo.setHgap(40);
        studentInfo.setVgap(40);
        
        GridPane bottom = new GridPane();
        bottom.setHgap(30);
        bottom.setVgap(30);
        
        GridPane top = new GridPane();
        top.setHgap(30);
        top.setVgap(30);
        top.setBackground(background);
        
        //Gridpanes and listview are inserted into a borderpane to
        //improve formatting
        BorderPane border = new BorderPane();
        border.setRight(studentInfo);
        border.setCenter(listView);
        border.setTop(top);
        border.setBottom(bottom);
        
        //Controls inserted into gridpanes
        studentInfo.add(lblStudentName,1,1);
        studentInfo.add(lblStudentBirth,3,1);
        studentInfo.add(lblAddress,1,2);
        studentInfo.add(lblCity,3,2);
        studentInfo.add(lblState,1,3);
        studentInfo.add(lblZip,3,3);
        studentInfo.add(lblParent1,1,4);
        studentInfo.add(lblParentName1,3,4);
        studentInfo.add(lblParentBirth1,1,5);
        studentInfo.add(lblParentPhone1,3,5);
        studentInfo.add(lblParent2,1,6);
        studentInfo.add(lblParentName2,3,6);
        studentInfo.add(lblParentBirth2,1,7);
        studentInfo.add(lblParentPhone2,3,7);
        
        bottom.add(btnDel,2,2);
        bottom.add(btnInfo,1,2);
        bottom.add(lblEmpty2,0,3);
        
        top.add(btnBack,0,0);
        top.add(lblDir,1,1);
        top.add(lblEmpty,0,2);
        
        //Action Event for 'back' button, closes the StudentDirectory class
        //Stage and opens up GUIChoice class Stage
        btnBack.setOnAction(e->{
            primaryStage.hide();
            GUIChoice g = new GUIChoice();
            g.start(new Stage());
        });
        
        //Action Event for 'More Info' button, allows the user to display
        //more information about the selected student ID
        btnInfo.setOnAction(e->{
            
            String SQL = "SELECT * FROM registration WHERE ID = " + listView.getSelectionModel().getSelectedItem();
            
            //Connect to the database and find the information of the selected
            //user ID
            try{
                Connection conn = DriverManager.getConnection(DB);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(SQL);
                
                //Finds the selected ID and prints out all of the information
                //from the database onto the scene
                while(rs.next()){
                    lblStudentName.setText("Name: " + rs.getString("name"));
                    lblStudentBirth.setText("DOB: " + rs.getString("birth"));
                    lblAddress.setText("Address: " + rs.getString("address"));
                    lblCity.setText("City: " + rs.getString("city"));
                    lblState.setText("State: " + rs.getString("state"));
                    lblZip.setText("ZIP Code: " + rs.getString("zipCode"));
                    lblParent1.setText("Parent 1: " + rs.getString("parent1"));
                    lblParentName1.setText("Name: " + rs.getString("parentname1"));
                    lblParentBirth1.setText("DOB: " + rs.getString("parentbirth1"));
                    lblParentPhone1.setText("Phone #: " + rs.getString("parentphone1"));
                    lblParent2.setText("Parent 2: " + rs.getString("parent2"));
                    lblParentName2.setText("Name: " + rs.getString("parentname2"));
                    lblParentBirth2.setText("Birth: " + rs.getString("parentbirth2"));
                    lblParentPhone2.setText("Phone #: " + rs.getString("parentphone2"));
                }
            }catch(Exception ex){
                System.out.println(ex.toString());
            }
        });
        
        //Action Event for the 'delete' button, the selected ID is deleted
        //from the listview and database
        btnDel.setOnAction(e->{
            deleteData(listView);
            loadData(listView);
        });
        
        //Create the scene and show the stage
        Scene scene = new Scene(border);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Directory");
        primaryStage.show();
        loadData(listView);
    }
    
    //Function used for listview to display the students
    //in the database in the application
    private void loadData(ListView <String> listView){
        
        String sql = "SELECT ID FROM registration";
        
        //empties the listview
        listView.getItems().clear();
        
        try{
            //Connects to the database
            Connection conn = DriverManager.getConnection(DB);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            //iterates through the database, printing out all
            //student IDs from the table into the listview
            while(rs.next()){
                String row = rs.getString("ID");
                
                listView.getItems().add(row);
            }
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    //function to delete data from the listview and database
    private void deleteData(ListView <String> listView){
        
        String SQL = "DELETE FROM registration WHERE ID = " + listView.getSelectionModel().getSelectedItem();

        try{
            //connects to the database
            Connection conn = DriverManager.getConnection(DB);
            Statement stmt = conn.createStatement();
            
            //after pressing the 'delete' button in the application,
            //an alert pops up to verify if the user wants
            //to delete the selected user's information
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Are you sure?");
            alert.setContentText("Deleting this user cannot be undone.");
            
            Optional<ButtonType> result = alert.showAndWait();
            
            //determines whether or not the user selected OK. if OK is
            //pressed, the user is deleted and the listview is refreshed.
            //if CANCEL is pressed, the alert closes and nothing happens.
            if(result.get() == ButtonType.OK){
                stmt.executeUpdate(SQL);
            }
            else if(result.get() == ButtonType.CANCEL){
                return;
            }
            
            
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    //main function
    public static void main(String[] args) {
        launch(args);
    }
    
}