
package pkg113project;

//imported libraries
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class GUIChoice extends Application {

    //function that displays the stage
    @Override
    public void start(Stage primaryStage){
        //Formatting and controls for the application
        Font titleFont = Font.font("Arial",FontWeight.BOLD,25);
        
        Label lblTop = new Label("Welcome!");
        lblTop.setFont(titleFont);
        lblTop.setUnderline(true);
        
        Button btnReg = new Button("Register New Student");
        Button btnDis = new Button("Display Students");
        Button btnExit = new Button("Exit");
        
        Image image = new Image("File:SchoolDistrictLogin.png");
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(185);
        imageView.setFitWidth(400);
        
        //The buttons are displayed in a Vbox format in order to keep
        //organized
        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(btnReg,btnDis,btnExit);
        vbox.setAlignment(Pos.CENTER);
        
        //Vbox, image and label are inserted into a borderpane for better
        //formatting
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(imageView);
        borderPane.setBottom(vbox);
        borderPane.setCenter(lblTop);
        
        //Action Event for the register button, hides the current stage
        //and displays the Main class stage
        btnReg.setOnAction(e->{
            primaryStage.hide();
            Main m = new Main();
            m.start(new Stage());
        });
        
        //Action Event for the diplay button, hides the current stage
        //and displays the StudentDirectory class stage
        btnDis.setOnAction(e->{
            primaryStage.hide();
            StudentDirectory s = new StudentDirectory();
            s.start(new Stage());
        });
        
        //Action Event for the exit button, hides the current stage
        //and ends the program
        btnExit.setOnAction(e->{
            Platform.exit();
        });
        
        //Creates the scene and displays the stage
        Scene scene = new Scene(borderPane, 400, 350);
        
        primaryStage.setScene(scene);
        primaryStage.setTitle("Directory");
        primaryStage.show();
    }
    
    //main function
    public static void main(String[] args) {
        launch(args);
    }
    
}
