
package pkg113project;

//java imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class Main extends Application {
    //String that will be used to connect to the database
    static final String DB = "jdbc:sqlite:Registration.db";
    
    @Override
    public void start(Stage primaryStage) {
        //Start off by formatting the scene for the javafx application,
        //whether thats fonts, labels and textfields, etc.
        Font titleFont = Font.font("Bell MT", FontWeight.BOLD, 40);
        Font sectionFont = Font.font("Arial",FontWeight.BOLD,15);
        Font parentFont = Font.font("Monospaced 14",FontWeight.BOLD,12);
        
        //Format labels filled with whitespace in order to create
        //proper spacing between different border areas
        Label lblEmptySpace1 = new Label("");
        Label lblEmptySpace2 = new Label("");
        
        BackgroundFill backgroundFill = new BackgroundFill(Color.DARKRED, CornerRadii.EMPTY, Insets.EMPTY);
        Background background = new Background(backgroundFill);
        
        Label lblTitle = new Label("Student Registration");
        lblTitle.setFont(titleFont);
        lblTitle.setUnderline(true);
        lblTitle.setTextFill(Color.color(1,1,1));
        Label lblStudent = new Label("Student Information");
        lblStudent.setFont(sectionFont);
        lblStudent.setUnderline(true);
        
        //Student Information
        Label lblStudentName = new Label("Full Name (Incl. Suffix):");
        Label lblStudentID = new Label("Student ID:");
        Label lblStudentBirth = new Label("Date of Birth (MM/DD/YYYY):");
        Label lblAddress = new Label("Address: ");
        Label lblCity = new Label("City: ");
        Label lblState = new Label("State: ");
        Label lblZIP = new Label("ZIP Code: ");
        TextField txtStudentName = new TextField();
        TextField txtStudentID = new TextField();
        DatePicker dpStudentBirth = new DatePicker();
        TextField txtAddress = new TextField();
        TextField txtCity = new TextField();
        TextField txtZIP = new TextField();
        
        //Parent Information
        Label lblParent = new Label("Parent Information");
        lblParent.setFont(sectionFont);
        lblParent.setUnderline(true);
        Label lblParentChoice1 = new Label("Parent 1:");
        lblParentChoice1.setFont(parentFont);
        Label lblParentBirth1 = new Label("Date of Birth (MM/DD/YYYY):");
        Label lblParentName1 = new Label("First/Last Name:");
        Label lblParentChoice2 = new Label("Parent 2:");
        lblParentChoice2.setFont(parentFont);
        Label lblParentBirth2 = new Label("Date of Birth (MM/DD/YYYY):");
        Label lblParentName2 = new Label("First/Last Name:");
        Label lblParentPhone1 = new Label("Phone Number:");
        Label lblParentPhone2 = new Label("Phone Number:");
        TextField txtParentPhone1 = new TextField();
        TextField txtParentPhone2 = new TextField();
        DatePicker dpParentBirth1 = new DatePicker();
        TextField txtParentName1 = new TextField();
        DatePicker dpParentBirth2 = new DatePicker();
        TextField txtParentName2 = new TextField();
        
        //Lists that will be used to create the combobox for parents.
        ObservableList<String> parentOptions1 = FXCollections.observableArrayList(
        "Father","Mother","Guardian","Other");
        
        ObservableList<String> parentOptions2 = FXCollections.observableArrayList(
        "Father","Mother","Guardian","Other");
        
        ObservableList<String> stateOptions = FXCollections.observableArrayList(
        "AL","AK","AZ","AR","AS","CA","CO","CT","DE","DC","FL","GA","GU","HI","ID",
                "IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE",
                "NV","NH","NJ","NM","NY","NC","ND","MP","OH","OK","OR","PA","PR","RI","SC","SD",
                "TN","TX","TT","UT","VT","VA","VI","WA","WV","WI","WY");
        
        ComboBox cbParentChoice1 = new ComboBox(parentOptions1);
        ComboBox cbParentChoice2 = new ComboBox(parentOptions2);
        ComboBox cbStateChoice = new ComboBox(stateOptions);
        
        //Buttons
        Button btnOK = new Button("Submit");
        btnOK.setPrefSize(100,50);
        Button btnClear = new Button("Clear");
        btnClear.setPrefSize(100,50);
        Button btnBack = new Button("<- Back");
        
        //Creating the format of which everything will be placed in the application.
        GridPane register = new GridPane();
        register.setHgap(10);
        register.setVgap(10);
        
        GridPane top = new GridPane();
        top.setHgap(30);
        top.setVgap(30);
        top.setBackground(background);
        
        GridPane bottom = new GridPane();
        bottom.setHgap(30);
        bottom.setVgap(30);
        
        //All GridPanes will be placed into this BorderPane in order
        //to format the application cleaner
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(top);
        borderPane.setCenter(register);
        borderPane.setBottom(bottom);
         
        //Adding all of the information to the application
        top.add(btnBack,0,0);
        top.add(lblTitle,2,1);
        top.add(lblEmptySpace2,6,2);
        
        register.add(lblStudent,0,1);
        register.add(lblStudentName,0,2);
        register.add(txtStudentName,1,2);
        register.add(lblStudentID,2,2);
        register.add(txtStudentID,3,2);
        register.add(lblStudentBirth,0,3);
        register.add(dpStudentBirth,1,3);
        register.add(lblAddress,0,4);
        register.add(txtAddress,1,4);
        register.add(lblCity,2,4);
        register.add(txtCity,3,4);
        register.add(lblState,0,5);
        register.add(cbStateChoice,1,5);
        register.add(lblZIP,2,5);
        register.add(txtZIP,3,5);
        register.add(lblParent,0,6);
        register.add(lblParentChoice1,0,7);
        register.add(cbParentChoice1,1,7);
        register.add(lblParentName1,0,8);
        register.add(txtParentName1,1,8);
        register.add(lblParentPhone1,2,8);
        register.add(txtParentPhone1,3,8);
        register.add(lblParentBirth1,0,9);
        register.add(dpParentBirth1,1,9);
        register.add(lblParentChoice2,0,10);
        register.add(cbParentChoice2,1,10);
        register.add(lblParentName2,0,11);
        register.add(txtParentName2,1,11);
        register.add(lblParentPhone2,2,11);
        register.add(txtParentPhone2,3,11);
        register.add(lblParentBirth2,0,12);
        register.add(dpParentBirth2,1,12);
        
        bottom.add(btnOK,0,0);
        bottom.add(btnClear,1,0);
        bottom.add(lblEmptySpace1,0,1);
        
        //Action Event that is set to activate when the "Submit" Button
        //is selected. This button creates variables for all textfields
        //and then connects to the database to insert said data.
        btnOK.setOnAction(e ->{
           int studentID = Integer.parseInt(txtStudentID.getText());
           String studentName = txtStudentName.getText();
           String studentBirth = dpStudentBirth.getValue().toString();
           String address = txtAddress.getText();
           String city = txtCity.getText();
           String state = cbStateChoice.getValue().toString();
           int zipCode = Integer.parseInt(txtZIP.getText());
           
           String parentChoice1 = cbParentChoice1.getValue().toString();
           String parentName1 = txtParentName1.getText();
           String parentBirth1 = dpParentBirth1.getValue().toString();
           String parentPhone1 = txtParentPhone1.getText();
           
           String parentChoice2 = cbParentChoice2.getValue().toString();
           String parentName2 = txtParentName2.getText();
           String parentBirth2 = dpParentBirth2.getValue().toString();
           String parentPhone2 = txtParentPhone2.getText();
           
           if(parentPhone1.length() < 10 || parentPhone1.length() > 11 || parentPhone2.length() < 10 ||
                   parentPhone2.length() > 11){
               JOptionPane.showMessageDialog(null,"Invalid Phone Number.");
           }
           else{
               insertData(studentID, studentName, studentBirth, address,city,state,zipCode,
                   parentChoice1,parentName1,parentBirth1,parentChoice2,parentName2,parentBirth2, parentPhone1, parentPhone2);
           }
           
        });
        
        //Action Event that is called when the "Clear" button is pressed,
        //all textfields are emptied.
        btnClear.setOnAction(e ->{
           txtStudentID.setText("");
           txtStudentName.setText("");
           txtAddress.setText("");
           txtCity.setText("");
           cbStateChoice.valueProperty().set(null);
           txtZIP.setText("");
           txtParentName1.setText("");
           txtParentName2.setText("");
           dpStudentBirth.valueProperty().set(null);
           dpParentBirth1.valueProperty().set(null);
           dpParentBirth2.valueProperty().set(null);
           cbParentChoice1.valueProperty().set(null);
           cbParentChoice2.valueProperty().set(null);
           txtParentPhone1.setText("");
           txtParentPhone2.setText("");
        });
        
        btnBack.setOnAction(e->{
            primaryStage.hide();
            GUIChoice g = new GUIChoice();
            g.start(new Stage());
        });
        
        Scene scene = new Scene(borderPane,610,700);
        
        primaryStage.setScene(scene);
        primaryStage.setTitle("Student Registration");
        primaryStage.show();
    }
    
    //Function that takes all the inserted data, connects to the database, and updates it.
    public void insertData(int ID, String name, String birth, String address, String city, String state,
            int zip, String parent1, String parentName1, String parentBirth1, String parent2, String parentName2,
            String parentBirth2, String parentPhone1, String parentPhone2){
        
        try{
            //Connect to the database
               Connection conn = DriverManager.getConnection(DB);
               Statement stmt = conn.createStatement();
               
               //String used to insert the user's inputted data into
               //the database as a new table value
               String query = "Insert into registration(id,name,birth,address,city,state,zipCode,parent1,parentname1,parentbirth1,parentphone1,parent2,parentname2,parentbirth2,parentphone2)"
                       + " values ('"+ID+"' ,'"+name+"','"+birth+"','"+address+"','"+city+"','"+state+"','"+zip+"',"
                       + "'"+parent1+"','"+parentName1+"','"+parentBirth1+"','"+parentPhone1+"','"+parent2+"','"+parentName2+"','"+parentBirth2+"','"+parentPhone2+"')";
               
               stmt.executeUpdate(query);
               
               //Alert pops up to confirm the registration
               Alert alert = new Alert(Alert.AlertType.INFORMATION);
               alert.setContentText("Registration Complete!");
               alert.show();

               conn.close();
               stmt.close();
               
           }catch(Exception ex){
               System.out.println(ex.toString());
           }
    }

    //main function
    public static void main(String[] args) {
        launch(args);
    }
    
}
